<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>
    <form method="post" action='process.php'>
        Nazwa quizu: <input type="text" name="name" id=""><br>
        <input type="submit" value="Create">
    </form></div>
</form>

    
</body>
</html>
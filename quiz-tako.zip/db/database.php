<?php include_once '..\includes\header.php'; ?>
<main>
    <div class="container">
    <h1>Data Base PHP</h1>
    </div>
</main>
<?php include_once '..\includes\footer.php'; ?>